using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class HomeController : Controller
{
    private readonly AppDbContext _context;

    public HomeController(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var productos = await _context.Productos.ToListAsync();
        return View(productos);
    }

    public async Task<IActionResult> VerTabla()
    {
        var productos = await _context.Productos.ToListAsync();
        return View("TablaCompleta", productos);
    }

    [HttpPost]
    public async Task<IActionResult> AgregarProducto(string nombre, decimal precio)
    {
        if (string.IsNullOrWhiteSpace(nombre) || precio <= 0)
        {
            return RedirectToAction("Index"); // Evita insertar valores inv�lidos
        }

        var producto = new Producto { Nombre = nombre, Precio = precio };
        _context.Productos.Add(producto);
        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
    }

    [HttpPost]
    public async Task<IActionResult> EditarProducto(int id, string nombre, decimal precio)
    {
        var producto = await _context.Productos.FindAsync(id);
        if (producto == null)
        {
            return NotFound();
        }

        producto.Nombre = nombre;
        producto.Precio = precio;
        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
    }

    [HttpPost]
    public async Task<IActionResult> EliminarProducto(int id)
    {
        var producto = await _context.Productos.FindAsync(id);
        if (producto == null)
        {
            return NotFound();
        }

        _context.Productos.Remove(producto);
        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
    }
}
