﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;

namespace TestCreate
{
    public class ProductoCreate : IDisposable
    {
        private readonly IWebDriver driver;

        public ProductoCreate()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--start-maximized"); 
            driver = new ChromeDriver(options);
        }

        [Fact]
        public void Create_Producto_ReturnData()
        {
            try
            {
                // Navegar a la página donde se crea un producto
                driver.Navigate().GoToUrl("http://localhost:5000/");

                Thread.Sleep(2000); // Esperar carga de la página

                // Ingresar datos en los campos
                driver.FindElement(By.Name("nombre")).SendKeys("Laptop Gamer");
                Thread.Sleep(1000);
                driver.FindElement(By.Name("precio")).SendKeys("1500.99");
                Thread.Sleep(1000);

                // Hacer clic en el botón "Agregar Producto"
                driver.FindElement(By.XPath("//button[contains(text(),'Agregar Producto')]")).Click();
                Thread.Sleep(2000);

                // Verificar que el producto fue agregado correctamente
                string pageSource = driver.PageSource;
                Assert.Contains("Laptop Gamer", pageSource);
                Assert.Contains("$1500,99", pageSource);

                Console.WriteLine("✅ Prueba de creación de producto finalizada.");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("❌ Error: Elemento no encontrado - " + e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error durante la prueba: " + ex.Message);
            }
        }

        public void Dispose()
        {
            driver?.Quit();
        }
    }
}

