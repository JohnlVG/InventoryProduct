﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using Xunit;

namespace TestCreate
{
    public class ProductoDelete : IDisposable
    {
        private readonly IWebDriver driver;

        public ProductoDelete()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--start-maximized"); 
            driver = new ChromeDriver(options);
        }

        [Fact]
        public void Delete_Producto()
        {
            try
            {
                driver.Navigate().GoToUrl("http://localhost:5000/");
                Thread.Sleep(2000); 

                
                var eliminarButton = driver.FindElement(By.XPath("//table//tr[2]//button[contains(text(),'Eliminar')]"));

                // Desplazar hasta el botón y hacer clic
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", eliminarButton);
                Thread.Sleep(1000);

                Actions actions = new Actions(driver);
                actions.MoveToElement(eliminarButton).Click().Perform();
                Thread.Sleep(2000);

                // Confirmar alerta
                IAlert alert = driver.SwitchTo().Alert();
                alert.Accept();
                Thread.Sleep(3000);

                Console.WriteLine("✅ Prueba de eliminación completada.");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("❌ Elemento no encontrado: " + e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error durante la prueba: " + ex.Message);
            }
        }

        public void Dispose()
        {
            driver?.Quit();
        }
    }
}
