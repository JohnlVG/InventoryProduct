﻿using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Xunit;

namespace TestEdit
{
    public class ProductoEdit : IDisposable
    {
        private readonly IWebDriver driver;

        public ProductoEdit()
        {
            ChromeOptions options = new ChromeOptions();
            options.AddArgument("--start-maximized"); 
            driver = new ChromeDriver(options);
        }

        [Fact]
        public void Edit_Producto_Update()
        {
            try
            {
                // Navegar a la página donde están los productos
                driver.Navigate().GoToUrl("http://localhost:5000/");
                Thread.Sleep(2000); // Esperar carga de la página

                // Buscar el campo de precio del producto "Smartwatch X100"
                var precioField = driver.FindElement(By.XPath("//tr[td[contains(text(),'Smartwatch X100')]]//input[@name='precio']"));

                // Asegurar que el campo está visible
                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].scrollIntoView(true);", precioField);
                Thread.Sleep(1000);

                // Limpiar el campo de precio completamente
                precioField.Clear();
                Thread.Sleep(500);

                // Ingresar el nuevo precio en formato correcto (con coma `,` en lugar de punto `.`)
                precioField.SendKeys("220");
                Thread.Sleep(1000);

                // Hacer clic en el botón "Editar" correspondiente a la fila del producto
                var editarButton = driver.FindElement(By.XPath("//tr[td[contains(text(),'Smartwatch X100')]]//button[contains(text(),'Editar')]"));
                editarButton.Click();
                Thread.Sleep(2000);

                // Verificar que el producto editado aparece correctamente en la tabla
                string pageSource = driver.PageSource;
                Assert.Contains("Smartwatch X100", pageSource);
                Assert.Contains("$249,99", pageSource); // Verificar el formato correcto

                Console.WriteLine("✅ Prueba de edición de producto finalizada correctamente.");
            }
            catch (NoSuchElementException e)
            {
                Console.WriteLine("❌ Error: No se encontró el elemento - " + e.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("❌ Error durante la prueba: " + ex.Message);
            }
        }

        public void Dispose()
        {
            driver?.Quit();
        }
    }
}

